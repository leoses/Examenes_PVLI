# Plantilla para juegos en Phaser

Plantilla básica para juegos en Phaser. Hace falta un servidor web para que se ejecute. Por ejemplo:

```bash
npx http-server
```
